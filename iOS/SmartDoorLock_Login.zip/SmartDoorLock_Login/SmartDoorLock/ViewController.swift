//
//  ViewController.swift
//  SmartDoorLock
//
//  Created by Dongheon Ryu on 2018. 5. 15..
//  Copyright © 2018년 Dongheon Ryu. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn

class ViewController: UIViewController, GIDSignInUIDelegate {

    //Sign in Button
    @IBAction func signInBtn(_ sender: Any) {
        GIDSignIn.sharedInstance().signIn()
    }
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    //Sign up with email
    @IBAction func emailLogInBtn(_ sender: Any) {
        Auth.auth().createUser(withEmail: emailTextField.text!, password: passwordTextField.text!) { (user, error) in
            
            //when error occurs
            if(error != nil) {
                
                //Log in
                Auth.auth().signIn(withEmail: self.emailTextField.text!, password: self.passwordTextField.text!) { (user, error) in
                    print("Login!\n")
                }
            
            
            }
            //when Email doesnt exist
            else{
                //when Success then Alert this message
                let alert = UIAlertController(title: "Sign Up Success!",
                                              message: "Success!", preferredStyle: UIAlertControllerStyle.alert)
                
                //add Action button in Alert messeage
                alert.addAction(UIAlertAction(title: "OK",style: UIAlertActionStyle.default, handler: nil))
                
                //finish alert set and present alert
                self.present(alert,animated: true, completion: nil)
                
            }

        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Google Sign in
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().signIn()
        
        
        
        Auth.auth().addStateDidChangeListener({(user,err) in
            if user != nil {
                self.performSegue(withIdentifier: "Home", sender: nil)
            }
        })
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

